import React, { useState } from 'react';
import './LoginForm.css';

function SignUpForm({ onSignUp }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSignUp = (e) => {
    e.preventDefault();
    // For demo, directly sign up and login
    onSignUp(username);
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1>Create Account</h1>
        <form onSubmit={handleSignUp}>
          <input type="text" placeholder="Choose username" value={username} onChange={(e) => setUsername(e.target.value)} required />
          <input type="password" placeholder="Choose password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          <button type="submit">Sign Up</button>
        </form>
      </div>
    </div>
  );
}

export default SignUpForm;
