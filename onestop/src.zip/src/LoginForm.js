import React, { useState } from 'react';
import './LoginForm.css';

function LoginForm({ onLogin, onSwitch }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simple dummy validation for demonstration
    if (username === 'admin' && password === 'password') {
      onLogin(username);
    } else {
      setMessage('❌ Invalid username or password');
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h1>Login</h1>
        <form onSubmit={handleSubmit}>
          <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          <button type="submit">Sign In</button>
        </form>
        {message && <div className="message">{message}</div>}
        <p>New here? <button onClick={onSwitch} className="link-button">Sign Up</button></p>
      </div>
    </div>
  );
}

export default LoginForm;
