// src/Dashboard.js
import React, { useState } from 'react';
import './Dashboard.css';
import CourseToCareer from './CourseToCareer';
import CollegeDirectory from './CollegeDirectory'; // ⬅️ Import the component

function Dashboard({ username }) {
  const [activeView, setActiveView] = useState('main');

  if (activeView === 'career-mapping') {
    return <CourseToCareer onBack={() => setActiveView('main')} />;
  }

  if (activeView === 'college-directory') {
    return <CollegeDirectory onBack={() => setActiveView('main')} />;
  }

  return (
    <div className="dashboard-container">
      <h1>Welcome, {username}!</h1>
      <p>Select an option to explore:</p>

      <div className="dashboard-grid">
        <div className="dashboard-card">📝 Aptitude Quiz</div>
        
        <div 
          className="dashboard-card" 
          onClick={() => setActiveView('career-mapping')}
        >
          🚀 Course to Career Mapping
        </div>
        
        <div 
          className="dashboard-card"
          onClick={() => setActiveView('college-directory')}
        >
          🏫 College Directory
        </div>
        
        <div className="dashboard-card">⏱ Timeline Tracker</div>
      </div>
    </div>
  );
}

export default Dashboard;
